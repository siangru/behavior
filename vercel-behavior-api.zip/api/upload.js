
// api/upload.js
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // 預檢請求 (CORS)
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const body = req.body;

    // 你的 Google Apps Script URL
    const GAS_URL = "https://script.google.com/macros/s/AKfycbzUV3qvlA1FY5hJgBPrB7TfvVY6N7vHSquIy1LTloQJxRjwCMm7P0l9wx1fc0IA6Owz/exec";

    // 將資料轉送到 Google Apps Script
    const response = await fetch(GAS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const text = await response.text();
    res.status(200).json({ success: true, message: 'Data forwarded', response: text });

  } catch (error) {
    console.error('Error forwarding to GAS:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}
